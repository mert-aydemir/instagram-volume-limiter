const volumeSlider = document.getElementById('volumeSlider');
const volumeValueDisplay = document.getElementById('volumeValue');
const enableSwitch = document.getElementById('enableSwitch'); // Anahtarı seç
const switchLabel = document.querySelector('.switch-label'); // Anahtar etiketini seç
const sliderArea = document.getElementById('sliderArea'); // Slider'ın kapsayıcısını seç
const defaultVolume = 0.05;
const defaultEnabled = true; // Varsayılan olarak eklenti aktif olsun

// Kaydedilmiş ayarları yükle (hem ses seviyesi hem de aktiflik durumu)
function loadSettings() {
    console.log("Popup: Loading settings (volume and enabled state)...");
    browser.storage.local.get(['volumeLevel', 'isEnabled'], (data) => {
        if (browser.runtime.lastError) {
            console.error("Popup: Error loading settings:", browser.runtime.lastError);
            // Hata durumunda varsayılanları kullan
            volumeSlider.value = defaultVolume;
            updateVolumeDisplay(defaultVolume);
            enableSwitch.checked = defaultEnabled;
            updateUiState(defaultEnabled); // UI'ı güncelle
            return;
        }
        console.log("Popup: Storage result:", data);

        // Ses seviyesini ayarla
        const currentVolume = (data && data.volumeLevel !== undefined) ? data.volumeLevel : defaultVolume;
        console.log("Popup: Setting slider value to:", currentVolume);
        volumeSlider.value = currentVolume;
        updateVolumeDisplay(currentVolume);

        // Aktiflik durumunu ayarla
        const isEnabled = (data && data.isEnabled !== undefined) ? data.isEnabled : defaultEnabled;
        console.log("Popup: Setting enabled state to:", isEnabled);
        enableSwitch.checked = isEnabled;
        updateUiState(isEnabled); // UI'ı güncelle
    });
}

// Ses seviyesi göstergesini güncelle
function updateVolumeDisplay(value) {
    const percentage = Math.round(value * 100);
    volumeValueDisplay.textContent = `${percentage}%`;
}

// Anahtarın durumuna göre UI'ı güncelle (slider'ı etkinleştir/devre dışı bırak)
function updateUiState(isEnabled) {
    if (isEnabled) {
        sliderArea.classList.remove('disabled');
        volumeSlider.disabled = false;
        switchLabel.textContent = "Eklenti Aktif";
        // document.body.classList.remove('disabled-state'); // Opsiyonel: Arka plan rengini eski haline getir
    } else {
        sliderArea.classList.add('disabled');
        volumeSlider.disabled = true;
        switchLabel.textContent = "Eklenti Pasif";
        // document.body.classList.add('disabled-state'); // Opsiyonel: Arka planı değiştir
    }
}

// --- Event Listeners ---

// Kaydırıcı değeri değiştiğinde
volumeSlider.addEventListener('input', (event) => {
    // Sadece eklenti aktifken çalışsın
    if (!enableSwitch.checked) return;

    const newVolume = parseFloat(event.target.value);
    // console.log("Popup: Slider input detected. New value:", newVolume);
    updateVolumeDisplay(newVolume);
    // Ayarı kaydet
    browser.storage.local.set({ volumeLevel: newVolume }, () => {
        if (browser.runtime.lastError) {
            console.error("Popup: Error saving volumeLevel:", browser.runtime.lastError);
        }
    });
});

// Anahtar durumu değiştiğinde
enableSwitch.addEventListener('change', (event) => {
    const isEnabled = event.target.checked;
    console.log("Popup: Switch changed. New state:", isEnabled);
    updateUiState(isEnabled); // UI'ı anında güncelle
    // Yeni durumu kaydet
    browser.storage.local.set({ isEnabled: isEnabled }, () => {
        if (browser.runtime.lastError) {
            console.error("Popup: Error saving isEnabled state:", browser.runtime.lastError);
        } else {
            console.log("Popup: Enabled state saved successfully to local storage:", isEnabled);
        }
    });
});

// Popup açıldığında ayarları yükle
document.addEventListener('DOMContentLoaded', loadSettings);